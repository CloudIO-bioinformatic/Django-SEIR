from django.shortcuts import render
import json

from django.core import serializers
from .models import Comuna
from .models import listacomunas
from .models import listaregiones
from .models import estadisticas
from .models import cluster
# Create your views here.
from django.conf import settings

def home(request):
    return render(request,"principal.html",{'settings':settings})

def seirchile(request):
    listaregion = listaregiones.objects.all()
    clusters = cluster.objects.filter(necesidad='EXTREMA')
    return render(request, "seirchile.html",{'settings':settings, 'listaregion':listaregion, 'clusters':clusters})

def region(request):
    region_post = request.POST['region']
    listacomuna = listacomunas.objects.filter(region=str(region_post))
    return render(request, "region.html",{'settings':settings, 'listacomuna':listacomuna,'region':region_post})

def comuna(request):
    comuna_post = request.POST['comuna']
    datos = Comuna.objects.filter(comuna=str(comuna_post))
    estadisticas_comuna = estadisticas.objects.filter(comuna=str(comuna_post))
    dia = Comuna.objects.filter(comuna=str(comuna_post)).values('dia')
    S = Comuna.objects.filter(comuna=str(comuna_post)).values('S')
    E = Comuna.objects.filter(comuna=str(comuna_post)).values('E')
    I = Comuna.objects.filter(comuna=str(comuna_post)).values('I')
    R = Comuna.objects.filter(comuna=str(comuna_post)).values('R')
    estado = cluster.objects.filter(comuna=str(comuna_post))
    print(estado)
    for x in estado:
        print(x)
    return render(request, "comuna.html",{'estado':estado,'settings':settings, 'datos':datos,'nombre':comuna_post, 'estadisticas':estadisticas_comuna, 'dia_list':json.dumps(list(dia)),
    'S':json.dumps(list(S)),'E':json.dumps(list(E)),'I':json.dumps(list(I)),'R':json.dumps(list(R))})

def estado(request):
    cluster_post = request.POST['estado']
    if cluster_post == 'EXTREMA':
        clase = 'btn btn-danger btn-icon-split'
    if cluster_post == 'ALTA':
        clase = 'btn btn-primary btn-icon-split'
    if cluster_post == 'MEDIA':
        clase = 'btn btn-success btn-icon-split'
    if cluster_post == 'BAJA':
        clase = 'btn btn-info btn-icon-split'
    clusters = cluster.objects.filter(necesidad=str(cluster_post))
    return render(request, "estado.html",{'settings':settings, 'clusters':clusters,'estado':cluster_post,'clase':clase})
