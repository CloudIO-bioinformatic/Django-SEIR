from django.db import models

# Create your models here.

class Comuna(models.Model):
    date = models.CharField(max_length=200)
    region = models.CharField(max_length=200)
    comuna = models.CharField(max_length=200)
    dia = models.CharField(max_length=200)
    S = models.CharField(max_length=200)
    E = models.CharField(max_length=200)
    I = models.CharField(max_length=200)
    R = models.CharField(max_length=200)
    #class Meta:
     #   db_table = "comuna"
class listacomunas(models.Model):
    region = models.CharField(max_length=200)
    nombre = models.CharField(max_length=200)

class listaregiones(models.Model):

    nombre = models.CharField(max_length=200)

class estadisticas(models.Model):
    poblacion = models.CharField(max_length=200)
    comuna = models.CharField(max_length=200)
    maxS = models.CharField(max_length=200)
    maxE = models.CharField(max_length=200)
    maxI = models.CharField(max_length=200)
    maxR = models.CharField(max_length=200)
    dia = models.CharField(max_length=200)
    maxDia = models.CharField(max_length=200)
    poblacion_porcentaje = models.CharField(max_length=200)
class cluster(models.Model):
    comuna = models.CharField(max_length=200)
    necesidad = models.CharField(max_length=200)
